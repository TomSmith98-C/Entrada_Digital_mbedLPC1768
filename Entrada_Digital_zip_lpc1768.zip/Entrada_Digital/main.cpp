/*
            created by Tom Smith 
            April,17 2020
*/

#include "mbed.h"

DigitalIn push(p5);

Serial pc(USBTX,USBRX);

int main()
{
        
        pc.printf("Programa para lectura digital");
        while(1)
        {
            if(push == 1)
            {
                pc.printf("Se pulso el push button");
                wait(0.5);
            }
            else 
            {
                pc.printf("No se ha pulsado nada");
                wait(0.5);
            }
        }
}        
            