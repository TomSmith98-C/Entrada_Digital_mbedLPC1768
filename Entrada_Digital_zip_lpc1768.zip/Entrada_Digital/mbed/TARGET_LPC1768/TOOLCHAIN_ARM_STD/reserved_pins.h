// List of reserved pins for MBED LPC1768

#ifndef RESERVED_PINS_H
#define RESERVED_PINS_H

#define TARGET_RESERVED_PINS {}

#endif
